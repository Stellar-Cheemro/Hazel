#pragma once
#include <Hazel/Asset/AssetTypes.h>
#include <Hazel/Core/Core.h>
#include <cstdint>
#include <filesystem>
namespace Hazel
{

struct HAZEL_API AssetMetadata
{
    AssetHandle Handle = 0;
    AssetType Type = AssetType::None;
    AssetDomain Domain = AssetDomain::None;
    AssetLoadState LoadState = AssetLoadState::Unloaded;

    std::filesystem::path FilePath;

    operator bool() const
    {
        return Handle != 0 && Type != AssetType::None;
    }
    bool IsValid() const
    {
        return Handle != 0 && Type != AssetType::None;
    }
    bool HasFilePath() const
    {
        return !FilePath.empty();
    }
    bool IsFileAsset() const
    {
        return HasFilePath() && Domain != AssetDomain::Memory;
    }
    bool IsMemoryAsset() const
    {
        return Domain == AssetDomain::Memory;
    }
    std::filesystem::path GetFileSystemPath() const
    {
        return FilePath.lexically_normal();
    }
};
} // namespace Hazel