#pragma once
#include <Hazel/Asset/Asset.h>
#include <Hazel/Asset/AssetMetadata.h>
#include <Hazel/Asset/AssetRegistry.h>
#include <Hazel/Asset/AssetSerializer.h>
#include <Hazel/Core/Ref.h>
#include <Hazel/Core/Scope.h>
namespace Hazel
{
class HAZEL_API AssetManager
{
public:
    static void Init();
    static void Shutdown();

    static AssetHandle ImportAsset(const std::filesystem::path& relativePath);

    static const AssetMetadata* GetMetadata(AssetHandle Handle);
    static AssetMetadata* GetMetadataMutable(AssetHandle Handle);

    static std::filesystem::path GetFileSystemPath(AssetHandle Handle);
    static std::filesystem::path GetFileSystemPath(const AssetMetadata& metadata);

    static bool IsAssetHandleValid(AssetHandle Handle);
    static bool IsAssetLoaded(AssetHandle Handle);

    template <typename T> static Ref<T> GetAsset(AssetHandle Handle)
    {
        auto loadedIt = s_LoadedAssets.find(Handle);
        if (loadedIt != s_LoadedAssets.end())
        {
            return loadedIt->second.As<T>();
        }

        AssetMetadata* metadata = GetMetadataMutable(Handle);
        if (!metadata)
        {
            return nullptr;
        }

        Ref<Asset> asset = LoadAsset(*metadata);
        if (!asset)
        {
            return nullptr;
        }
        metadata->IsLoaded = true;
        s_LoadedAssets[Handle] = asset;
        return asset.As<T>();
    }

private:
    static AssetHandle GenerateHandle();
    static AssetType GetAssetTypeFromExtension(const std::filesystem::path& path);
    static Ref<Asset> LoadAsset(const AssetMetadata& metadata);

private:
    static std::unordered_map<AssetHandle, Ref<Asset>> s_LoadedAssets;
    static std::unordered_map<AssetType, Scope<AssetSerializer>> s_Serializers;
    static Ref<AssetRegistry> s_AssetRegistry;
};
} // namespace Hazel