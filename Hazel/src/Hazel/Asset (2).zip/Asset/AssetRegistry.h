#pragma once
#include <Hazel/Asset/AssetMetadata.h>
#include <Hazel/Core/Core.h>
#include <Hazel/Core/Ref.h>
#include <filesystem>
#include <unordered_map>

namespace Hazel
{
class HAZEL_API AssetRegistry : public RefCounted
{
public:
    bool IsContained(AssetHandle Handle) const;
    bool IsContained(const std::filesystem::path& path) const;

    const AssetMetadata* GetMetadata(AssetHandle Handle) const;
    AssetMetadata* GetMetadata(AssetHandle Handle);
    AssetHandle GetHandleFromPath(const std ::filesystem::path& relativePath) const;

    void RegisterAsset(const AssetMetadata& metadata);
    bool RemoveAsset(AssetHandle Handle);
    void Clear();

private:
    static std::filesystem::path NormalizePath(const std::filesystem::path& path);

private:
    std::unordered_map<AssetHandle, AssetMetadata> m_HandleToMetadata;
    std::unordered_map<std::filesystem::path, AssetHandle> m_PathToHandle;
};
} // namespace Hazel
