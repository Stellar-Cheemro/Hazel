#pragma once
#include <cstdint>

namespace Hazel
{
using AssetHandle = uint64_t;
enum class AssetType : uint16_t
{
    None = 0,
    Texture2D,
    Shader,
    Scene,
    Mesh,
    Audio
};
enum class AssetDomain : uint8_t
{
    None = 0,
    Engine,
    Project,
    Memory
};

} // namespace Hazel
